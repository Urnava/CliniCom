//
//  PatientsPage.swift
//  Clinicom
//
//  Created by user1 on 26/03/24.
//

import SwiftUI

struct PatientsPage: View {
    @State private var isAddPatientViewPresented = false
    @State private var patients: [String: Bool] = [:] // Dictionary to store patient names and their active/inactive status
    @State private var selectedFilterIndex = 0
    
    var filteredPatients: [(String, Bool)] {
        let isActive = selectedFilterIndex == 0
        return patients.filter { $0.value == isActive }
    }
    
    @ObservedObject var signingAPI: usersModel
    @ObservedObject var patientAPI: patientsModel
    @Binding var pageState: String
    @Binding var currentPatientId: Int
    
    @State var searchKey: String = ""
    
    @State private var isLogged: Bool = UserDefaults.standard.bool(forKey: "LoginState")
    @State private var loggedUserID: String = UserDefaults.standard.string(forKey: "LoggedUserID") ?? ""
    @State private var loggedUserName: String = UserDefaults.standard.string(forKey: "LoggedUserName") ?? ""
    @State private var loggedUserEmail: String = UserDefaults.standard.string(forKey: "LoggedUserEmail") ?? ""
    
    var body: some View {
        VStack{
            HStack{
                Button(action:{
                    isAddPatientViewPresented = true
                }){
                    Image(systemName: "person.fill.badge.plus")
                        .symbolRenderingMode(.hierarchical)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.black)
                }
                Spacer()
                TextField("Search....", text: $searchKey)
                    .padding(10)
                    .font(.system(size: 12))
                    .background(.white.opacity(0.8))
                    .cornerRadius(10)
            }
            Picker(selection: $selectedFilterIndex, label: Text("")) {
                Text("Active").tag(0)
                Text("Inactive").tag(1)
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding(.vertical, 5)
            .frame(maxWidth: .infinity)
            ScrollView{
                VStack{
                    if(selectedFilterIndex == 0){
                        ForEach(patientAPI.activePatients, id: \.id){
                            patient in
                            Button(action:{
                                Task{
                                    do{
                                        currentPatientId = patient.id!
                                        try! await patientAPI.getCurrentPatient(id: currentPatientId)
                                        pageState = "PatientPage"
                                    }
                                }
                            }){
                                HStack{
                                    Text("\(patient.fullName)")
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .symbolRenderingMode(.hierarchical)
                                }
                                .foregroundColor(.black)
                                .font(.system(size: 14))
                                .frame(maxWidth: .infinity)
                                .padding(10)
                                .background(.white.opacity(0.8))
                                .cornerRadius(10)
                            }
                        }
                    }
                    else{
                        ForEach(patientAPI.inactivePatients, id: \.id){
                            patient in
                            Button(action:{
                                Task{
                                    do{
                                        currentPatientId = patient.id!
                                        try! await patientAPI.getCurrentPatient(id: currentPatientId)
                                        pageState = "PatientPage"
                                    }
                                }
                            }){
                                HStack{
                                    Text("\(patient.fullName)")
                                        .foregroundColor(.black)
                                        .frame(maxWidth: .infinity)
                                        .padding(10)
                                        .background(.white.opacity(0.8))
                                        .cornerRadius(10)
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .symbolRenderingMode(.hierarchical)
                                }
                                .font(.system(size: 12))
                            }
                        }
                    }
                }
            }
        }
        .padding(.horizontal,20)
        .padding(.vertical,10)
        .sheet(isPresented: $isAddPatientViewPresented, content: {
            AddPatientView(patientAPI: patientAPI)
        })
        .task {
            do{
                try! await patientAPI.getCurrentPatients(id: Int(loggedUserID)!)
            }
        }
    }
}

struct AddPatientView: View {
    @Environment(\.presentationMode) var presentationMode
    
    @ObservedObject var patientAPI: patientsModel
    
    @State private var name = ""
    @State private var contactNumber = ""
    @State private var age = ""
    @State private var weight = ""
    @State private var gender = ""
    @State private var bloodGroup = ""
    @State private var isPatientActive = true
    
    @State private var isLogged: Bool = UserDefaults.standard.bool(forKey: "LoginState")
    @State private var loggedUserID: String = UserDefaults.standard.string(forKey: "LoggedUserID") ?? ""
    @State private var loggedUserName: String = UserDefaults.standard.string(forKey: "LoggedUserName") ?? ""
    @State private var loggedUserEmail: String = UserDefaults.standard.string(forKey: "LoggedUserEmail") ?? ""
    
    //var onSave: (String, Bool) -> Void
    
    var body: some View {
        NavigationView {
                VStack(alignment: .leading, spacing: 10) {
                    
                    Text("Patient Details")
                        .font(.title3)
                        .foregroundColor(.black)
                        .padding(.horizontal)
                        .padding(.top)
                    
                    TextField("Name...", text: $name)
                        .padding(10)
                        .background(.black.opacity(0.1))
                        .cornerRadius(10)
                    
                    TextField("Mobile Number...", text: $contactNumber)
                        .padding(10)
                        .background(.black.opacity(0.1))
                        .cornerRadius(10)
                        .keyboardType(.numberPad)
                    
                    TextField("Age...", text: $age)
                        .padding(10)
                        .background(.black.opacity(0.1))
                        .cornerRadius(10)
                        .keyboardType(.numberPad)
                    
                    TextField("Weight...", text: $weight)
                        .padding(10)
                        .background(.black.opacity(0.1))
                        .cornerRadius(10)
                        .keyboardType(.numberPad)
                    
                    TextField("Gender...", text: $gender)
                        .padding(10)
                        .background(.black.opacity(0.1))
                        .cornerRadius(10)
                    
                    TextField("Blood Group...", text: $bloodGroup)
                        .padding(10)
                        .background(.black.opacity(0.1))
                        .cornerRadius(10)
                    
                    Spacer()
                }
                .font(.system(size: 16))
                .padding(.horizontal,20)
            
            .background(LinearGradient(gradient: Gradient(colors: [.green.opacity(0.5), .white]), startPoint: .bottom, endPoint: .top))
            .navigationBarTitle("New Patient", displayMode: .inline)
            .navigationBarItems(
                leading:
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.blue)
                            .imageScale(.large)
                    },
                trailing:
                    Button(action: {
                        Task{
                            do{
                                await savePatientDetails()
                                presentationMode.wrappedValue.dismiss()
                            }
                        }
                    }) {
                        Text("Save")
                            .foregroundColor(.blue)
                            .bold()
                    }
            )
        }
    }
    
    func savePatientDetails() async{
        try! await patientAPI.addPatient(fullName: name, mobileNumber: contactNumber, age: Int(age)!, weight: Int(weight)!, gender: gender, bloodGroup: bloodGroup, doctorID: Int(loggedUserID)!)
    }
}

struct RowView: View {
    let text: String
    
    var body: some View {
        Text(text)
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color("81AAAA"))
            .cornerRadius(10)
    }
}


struct prevPp: View {
    
    @State var StringVar: String = ""
    @State var IntegerVar: Int = 0
    @StateObject var signingAPI = usersModel()
    @StateObject var patientAPI = patientsModel()
    
    var body: some View {
        PatientsPage(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $StringVar, currentPatientId: $IntegerVar)
    }
}

//#Preview {
//    prevPp()
//}
