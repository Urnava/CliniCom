//
//  ProfilePage.swift
//  Clinicom
//
//  Created by user1 on 26/03/24.
//

import SwiftUI

struct ProfilePage: View {
    
    @ObservedObject var signingAPI: usersModel
    @Binding var pageState: String
    
    @State private var isEditing = false
    @State private var name = ""
    @State private var mobileNumber = ""
    @State private var medicalQualification = ""
    @State private var medicalToken = ""
    @State private var clinicAddress = ""

    
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading) {
                    // Profile photo
                    HStack {
                        Spacer()
                    }
                    
                    // Name
                    VStack(alignment: .leading) {
                        Text("Name:")
                            .font(.headline)
                            .padding(.horizontal)
                        TextField("\(signingAPI.currentDoctor[0].fullName)", text: $name)
                            .autocorrectionDisabled(true)
                            .autocapitalization(.none)
                            .padding()
                            .background(.black.opacity(0.05))
                            .cornerRadius(10)
                            .font(.system(size: 18, weight: .regular))
                            .disabled(!isEditing)
                            // Add spacing after text field
                    }
                    
                    // Contact Number
                    VStack(alignment: .leading) {
                        Text("Contact Number:")
                            .font(.headline)
                            .padding(.horizontal)
                        TextField("\(signingAPI.currentDoctor[0].mobileNumber)", text: $mobileNumber)
                            .autocorrectionDisabled(true)
                            .autocapitalization(.none)
                            .padding()
                            .background(.black.opacity(0.05))
                            .cornerRadius(10)
                            .font(.system(size: 18, weight: .regular))
                            .disabled(!isEditing) // Add spacing after text field
                    }
                    .padding(.vertical)
                    
                    // Degree
                    VStack(alignment: .leading) {
                        Text("Degree:")
                            .font(.headline)
                            .padding(.horizontal)
                        TextField("\(signingAPI.currentDoctor[0].medicalQualification)", text: $medicalQualification)
                            .autocorrectionDisabled(true)
                            .autocapitalization(.none)
                            .padding()
                            .background(.black.opacity(0.05))
                            .cornerRadius(10)
                            .font(.system(size: 18, weight: .regular))
                            .disabled(!isEditing) // Add spacing after text field
                    }
                    
                    // Registration Number
                    VStack(alignment: .leading) {
                        Text("Registration Number:")
                            .font(.headline)
                            .padding(.horizontal)
                        TextField("\(signingAPI.currentDoctor[0].medicalToken)", text: $medicalToken)
                            .autocorrectionDisabled(true)
                            .autocapitalization(.none)
                            .padding()
                            .background(.black.opacity(0.05))
                            .cornerRadius(10)
                            .font(.system(size: 18, weight: .regular))
                            .disabled(!isEditing) // Add spacing after text field
                    }
                    .padding(.vertical)
                    
                    // Clinic Address
                    VStack(alignment: .leading) {
                        Text("Clinic Address:")
                            .font(.headline)
                            .padding(.horizontal)
                        TextField("\(signingAPI.currentDoctor[0].clinicAddress)", text: $clinicAddress)
                            .autocorrectionDisabled(true)
                            .autocapitalization(.none)
                            .padding()
                            .background(.black.opacity(0.05))
                            .cornerRadius(10)
                            .font(.system(size: 18, weight: .regular))
                            .disabled(!isEditing) // Add spacing after text field
                    }
                    .padding(.vertical)
                    
                    Spacer()
                    
                    // Log out button
                    Button(action: {
                        UserDefaults.standard.set(false,forKey: "LoginState")
                        UserDefaults.standard.set("",forKey: "LoggedUserID")
                        UserDefaults.standard.set("",forKey: "LoggedUserName")
                        UserDefaults.standard.set("",forKey: "LoggedUserEmail")
                        pageState = "LaunchPage"
                    }) {
                        Text("Log Out")
                            .foregroundColor(.red)
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.red, lineWidth: 2)
                            )
                    }
                    .padding()
                    .padding(.horizontal)
                    .frame(maxWidth: .infinity, alignment: .center)
                }
            }
            .navigationBarTitle("My Profile", displayMode: .inline)
            .navigationBarItems(trailing: Button(action: {
                if isEditing {
                    // Save button tapped, perform save operation here
                }
                isEditing.toggle()
            }) {
                Text(isEditing ? "Save" : "Edit")
            })
            .padding()
        }
    }
}

//#Preview {
//    ProfilePage()
//}
