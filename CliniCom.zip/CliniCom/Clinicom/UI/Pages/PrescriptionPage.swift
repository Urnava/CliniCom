import SwiftUI

struct PrescriptionPage: View {
    
    @ObservedObject var signingAPI: usersModel
    @ObservedObject var patientAPI: patientsModel
    @Binding var pageState: String
    @Binding var patientId: Int
    
    var body: some View {
        NavigationView {
            VStack {
                
                    NavigationLink(destination: NewPrescriptionPage(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $pageState, patientId: $patientId) ){
                        Text("New Prescription")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(RoundedRectangle(cornerRadius: 10).fill(Color.blue))
                            .padding(.horizontal)
                    }
                    .padding(.top)
                
                ScrollView {
                    VStack(spacing: 10) {
                        ForEach(patientAPI.currentPatientPres, id: \.self) { fileName in
                            Text("\(fileName.id!)")
                                .foregroundColor(.black)
                                .padding()
                                .background(RoundedRectangle(cornerRadius: 10).fill(Color.gray.opacity(0.3)))
                        }
                    }
                    .padding()
                }
                Spacer()
            }
        }
        .navigationBarTitle("")
        .navigationBarHidden(true)
        .task {
            do{
                try! await patientAPI.getPres(id: patientId)
            }
        }
    }
}

struct prevPrp: View {
    
    @State var StringVar: String = ""
    @State var IntVar: Int = 0
    @StateObject var signingAPI = usersModel()
    @StateObject var patientAPI = patientsModel()
    
    var body: some View {
        PrescriptionPage(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $StringVar, patientId: $IntVar)
    }
}

#Preview {
    prevPrp()
}
