import SwiftUI
import Speech
import AVFoundation

class PatientDetailViewModel: ObservableObject {
    @Published var isRecordingDiagnosis = false
    @Published var diagnosisText = ""
    
    let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-IN"))
    let audioEngine = AVAudioEngine()
    var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    var recognitionTask: SFSpeechRecognitionTask?
    
    func requestSpeechAuthorization() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            // Handle speech recognition authorization status
            switch authStatus {
            case .authorized:
                print("Speech recognition authorized")
            case .denied:
                print("User denied speech recognition access")
            case .restricted:
                print("Speech recognition access restricted")
            case .notDetermined:
                print("Speech recognition authorization not determined")
            @unknown default:
                fatalError("Unhandled authorization status")
            }
        }
    }
    
    func toggleRecordingDiagnosis() {
        isRecordingDiagnosis.toggle()
        if isRecordingDiagnosis {
            startRecordingDiagnosis()
        } else {
            stopRecording()
        }
    }
    func startRecordingDiagnosis() {
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
            
            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            guard let recognitionRequest = recognitionRequest else { return }
            
            recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { result, error in
                guard let result = result else {
                    if let error = error {
                        print("Speech recognition error: \(error.localizedDescription)")
                    }
                    return
                }
                
                if error != nil || result.isFinal {
                    self.stopRecording()
                }
                
                let transcription = result.bestTranscription.formattedString
                DispatchQueue.main.async {
                    self.diagnosisText = transcription
                }
            }
            
            let recordingFormat = audioEngine.inputNode.outputFormat(forBus: 0)
            audioEngine.inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
                recognitionRequest.append(buffer)
            }
            
            audioEngine.prepare()
            try audioEngine.start()
        } catch {
            print("Audio session error: \(error.localizedDescription)")
        }
    }
    func stopRecording() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
    }
}

struct PatientDetailView: View {
    @ObservedObject var signingAPI: usersModel
    @ObservedObject var patientAPI: patientsModel
    @Binding var pageState: String
    @Binding var patientId: Int
    @StateObject var viewModel = PatientDetailViewModel()
    @State private var diagnosis: String = ""
    @State private var isCaseHistoryPresented = false
    @State private var isPrescriptionsPresented = false
    @State private var caseHistory: [String] = [] // Array to store case history
    @State private var isLogged: Bool = UserDefaults.standard.bool(forKey: "LoginState")
    @State private var loggedUserID: String = UserDefaults.standard.string(forKey: "LoggedUserID") ?? ""
    @State private var loggedUserName: String = UserDefaults.standard.string(forKey: "LoggedUserName") ?? ""
    @State private var loggedUserEmail: String = UserDefaults.standard.string(forKey: "LoggedUserEmail") ?? ""
    
    var body: some View {
        NavigationView{
            VStack(spacing: 20) {
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.black.opacity(0.1))
                    .frame(width: 360, height: 133)
                    .overlay(
                        VStack(alignment: .leading, spacing: 5) {
                            Text(patientAPI.currentPatient[0].fullName)
                                .font(.system(size: 30))
                                .foregroundColor(.white)
                            
                            Text(patientAPI.currentPatient[0].mobileNumber)
                                .font(.system(size: 22))
                                .foregroundColor(.white)
                        }
                        .padding(.horizontal, 20)
                    )
                
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.black.opacity(0.1))
                    .frame(width: 360, height: 200)
                    .overlay(
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Age: \(patientAPI.currentPatient[0].age)")
                                .font(.system(size: 20))
                                .foregroundColor(.white)
                            
                            Text("Weight: \(patientAPI.currentPatient[0].weight)")
                                .font(.system(size: 20))
                                .foregroundColor(.white)
                            
                            Text("Gender: \(patientAPI.currentPatient[0].gender)")
                                .font(.system(size: 20))
                                .foregroundColor(.white)
                            
                            Text("Blood Group: \(patientAPI.currentPatient[0].bloodGroup)")
                                .font(.system(size: 20))
                                .foregroundColor(.white)
                        }
                        .padding(.horizontal, 20)
                    )
                
                HStack {
                    Text("Diagnosis")
                        .font(.title2)
                        .foregroundColor(.black)
                        .padding(.trailing, 10)
                    
                    Spacer()
                    
                    Button(action: {
                        viewModel.toggleRecordingDiagnosis()
                    }) {
                        Image(systemName: viewModel.isRecordingDiagnosis ? "mic.fill" : "mic")
                            .foregroundColor(viewModel.isRecordingDiagnosis ? .red : .blue)
                    }
                    
                    Button(action: {
                        // Action to perform when the save button is tapped
                        saveDiagnosis()
                        Task{
                            do{
                                await saveDyg()
                            }
                        }
                    }) {
                        Image(systemName: "square.and.arrow.down")
                            .font(.title3)
                            .foregroundColor(.blue)
                            .padding(.leading)
                            .padding(.trailing)
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                .padding(.horizontal)
                
                TextField("", text: $viewModel.diagnosisText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)
                
                Button(action: {
                    isCaseHistoryPresented.toggle()
                }) {
                    Text("Case History")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(10)
                        .padding(.horizontal)
                }
                    .sheet(isPresented: $isCaseHistoryPresented) {
                        HistoryPage(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $pageState, patientId: $patientId)
                    }
                    .sheet(isPresented: $isPrescriptionsPresented){
                        PrescriptionPage(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $pageState, patientId: $patientId)
                    }
                
                Button(action: {
                    isPrescriptionsPresented.toggle()
                }) {
                    Text("Prescriptions")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.green)
                        .cornerRadius(10)
                        .padding(.horizontal)
                }
            }
            .navigationBarItems(leading: Button(action: {
                pageState = "PatientsPage"
            }) {
                Text("Back")
            })
            .navigationBarItems(trailing: Button(action: {
                pageState = "EditPage"
            }) {
                Text("Edit")
            })
        }
    }
        func saveDyg() async{
            try! await patientAPI.addHist(patientId: patientId, doctorID: Int(loggedUserID)!, fullName: patientAPI.currentPatient[0].fullName, mobileNumber: patientAPI.currentPatient[0].mobileNumber, age: patientAPI.currentPatient[0].age, weight: patientAPI.currentPatient[0].weight, gender: patientAPI.currentPatient[0].gender, bloodGroup: patientAPI.currentPatient[0].bloodGroup, analysis: viewModel.diagnosisText)
        }

    func saveDiagnosis() {
        guard !diagnosis.isEmpty else {
            return // Don't save if diagnosis is empty
        }
        
        // Generate file name using current date and patient's phone number
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyMMdd-HHmm"
        let dateString = dateFormatter.string(from: Date())
        let fileName = "\(dateString)_\(patientAPI.currentPatient[0].mobileNumber).txt"
        
        // Save diagnosis data to a file
        let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.appendingPathComponent(fileName)
        do {
            try diagnosis.write(to: fileURL, atomically: true, encoding: .utf8)
            
            // Append file name to case history
            caseHistory.append(fileName)
        } catch {
            print("Error saving diagnosis: \(error)")
        }
        }
}

struct PatientPage: View {
    
    @ObservedObject var signingAPI: usersModel
    @ObservedObject var patientAPI: patientsModel
    @Binding var pageState: String
    @Binding var patientId: Int
    
    var body: some View {
        PatientDetailView(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $pageState, patientId: $patientId)
    }
}

struct prevPpp: View {
    
    @State var StringVar: String = ""
    @State var IntVar: Int = 0
    @StateObject var signingAPI = usersModel()
    @StateObject var patientAPI = patientsModel()
    
    var body: some View {
        PatientPage(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $StringVar, patientId: $IntVar)
    }
}

//#Preview {
//    prevPpp()
//}
