import SwiftUI

struct SignupPage: View {
    
    @ObservedObject var signingAPI: usersModel
    @Binding var pageState: String
    
    @State var fullName: String = ""
    @State var emailAddress: String = ""
    @State var mobileNumber: String = ""
    @State var medicalToken: String = ""
    @State var medicalQualification: String = ""
    @State var clinicAddress: String = ""
    @State var password: String = ""
    @State var isPageLoading: Bool = false
    
    func addDoctor() async{
        
        isPageLoading.toggle()
        
        try! await signingAPI.addDoctor(fullName: fullName, emailAddress: emailAddress, mobileNumber: mobileNumber, medicalToken: medicalToken, medicalQualification: medicalQualification, clinicAddress: clinicAddress, password: password)
        if(signingAPI.responseStatus == 200){
            UserDefaults.standard.set(true,forKey: "LoginState")
            UserDefaults.standard.set(signingAPI.currentDoctor.first!.id,forKey: "LoggedUserID")
            UserDefaults.standard.set(signingAPI.currentDoctor.first!.fullName,forKey: "LoggedUserName")
            UserDefaults.standard.set(signingAPI.currentDoctor.first!.emailAddress,forKey: "LoggedUserEmail")
            
            pageState = "HomePage"
        }
        else{
            isPageLoading.toggle()
        }
    }
    
    var body: some View {
        VStack{
            Image(systemName: "cross.fill")
                .symbolRenderingMode(.hierarchical)
                .font(.system(size: 60, weight: .bold))
                .foregroundColor(.green)
                .shadow(radius: 5)
            Text("CliniCom")
                .font(.system(size: 20, weight: .medium))
            ScrollView{
                VStack(spacing:20){
                    TextField("Full Name...", text: $fullName)
                        .autocorrectionDisabled(true)
                        .autocapitalization(.none)
                        .padding()
                        .background(.black.opacity(0.05))
                        .cornerRadius(10)
                        .font(.system(size: 18, weight: .regular))
                    TextField("Email Address...", text: $emailAddress)
                        .autocorrectionDisabled(true)
                        .autocapitalization(.none)
                        .padding()
                        .background(.black.opacity(0.05))
                        .cornerRadius(10)
                        .font(.system(size: 18, weight: .regular))
                    TextField("Mobile Number...", text: $mobileNumber)
                        .autocorrectionDisabled(true)
                        .autocapitalization(.none)
                        .keyboardType(.numberPad)
                        .padding()
                        .background(.black.opacity(0.05))
                        .cornerRadius(10)
                        .font(.system(size: 18, weight: .regular))
                    TextField("Doctor Id...", text: $medicalToken)
                        .autocorrectionDisabled(true)
                        .autocapitalization(.none)
                        .padding()
                        .background(.black.opacity(0.05))
                        .cornerRadius(10)
                        .font(.system(size: 18, weight: .regular))
//                    Picker("Qualification...", selection: $medicalQualification){
//                        HStack{
//                            Text("MBBS").tag("MBBS")
//                            Spacer()
//                        }
//                        Text("MD").tag("MD")
//                        Text("BDS").tag("BDS")
//                    }
//                    .frame(maxWidth: .infinity)
//                    .accentColor(.black)
//                    .padding()
//                    .background(.black.opacity(0.05))
//                    .cornerRadius(10)
//                    .font(.system(size: 18, weight: .regular))
                    TextField("Qualification...", text: $medicalQualification)
                        .autocorrectionDisabled(true)
                        .autocapitalization(.none)
                        .padding()
                        .background(.black.opacity(0.05))
                        .cornerRadius(10)
                        .font(.system(size: 18, weight: .regular))
                    TextField("Clinic Address...", text: $clinicAddress)
                        .autocorrectionDisabled(true)
                        .autocapitalization(.none)
                        .padding()
                        .background(.black.opacity(0.05))
                        .cornerRadius(10)
                        .font(.system(size: 18, weight: .regular))
                    SecureField("Password...", text: $password)
                        .autocorrectionDisabled(true)
                        .autocapitalization(.none)
                        .padding()
                        .background(.black.opacity(0.05))
                        .cornerRadius(10)
                        .font(.system(size: 18, weight: .regular))
                    Button(action:{
                        Task{
                            do{
                                await addDoctor()
                            }
                        }
                    }){
                        if(isPageLoading){
                            Text("Loading...")
                                .padding(15)
                                .frame(maxWidth: .infinity)
                                .background(.green)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .font(.system(size: 18, weight: .bold))
                                .disabled(true)
                                .opacity(0.5)
                        }
                        else{
                            Text("Sign Up")
                                .padding(15)
                                .frame(maxWidth: .infinity)
                                .background(.green)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .font(.system(size: 18, weight: .bold))
                        }
                    }
                    HStack{
                        Text("Already have an account? ")
                        Button(action:{
                            Task{
                                pageState = "SigninPage"
                            }
                        }){
                            Text("Sign In")
                        }
                    }
                }
            }
            .padding(.vertical, 10)
        }
        .padding(.horizontal, 20)
    }
}

struct prevSup: View {
    
    @State var StringVar: String = ""
    @StateObject var signingAPI = usersModel()
    
    var body: some View {
        SignupPage(signingAPI: signingAPI, pageState: $StringVar)
    }
}

#Preview {
    prevSup()
}
