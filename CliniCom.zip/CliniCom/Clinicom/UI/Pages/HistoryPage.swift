import SwiftUI

struct HistoryPage: View {
    
    @ObservedObject var signingAPI: usersModel
    @ObservedObject var patientAPI: patientsModel
    @Binding var pageState: String
    @Binding var patientId: Int
    
    var body: some View {
        ZStack{
            LinearGradient(gradient: Gradient(colors: [.green.opacity(0.5), .white]), startPoint: .bottom, endPoint: .top)
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                Text("Case History")
                    .font(.title)
                    .foregroundColor(.black)
                    .padding()
                
                List {
                    ForEach(patientAPI.currentPatientHist, id: \.self) { fileName in
                        Text("\(fileName.analysis)")
                            .foregroundColor(.black)
                        Text("\(fileName.createdAt!)")
                            .foregroundColor(.black)
                    }
                }
                .listStyle(PlainListStyle())
                .padding()
            }
            .task {
                do{
                    try! await patientAPI.getHist(id: patientId)
                }
            }
        }
    }
}

struct prevHip: View {
    
    @State var StringVar: String = ""
    @State var IntVar: Int = 0
    @StateObject var signingAPI = usersModel()
    @StateObject var patientAPI = patientsModel()
    
    var body: some View {
        HistoryPage(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $StringVar, patientId: $IntVar)
    }
}

#Preview {
    prevHip()
}

