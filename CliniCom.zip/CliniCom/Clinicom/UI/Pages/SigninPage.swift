import SwiftUI

struct SigninPage: View {
    
    @ObservedObject var signingAPI: usersModel
    @Binding var pageState: String
    
    @State var emailAddress: String = ""
    @State var password: String = ""
    @State var isPageLoading: Bool = false
    
    func loginDoctor() async{
        
        isPageLoading.toggle()
        
        try! await signingAPI.loginDoctor(emailAddress: emailAddress, password: password)
        if(signingAPI.responseStatus == 200){
            UserDefaults.standard.set(true,forKey: "LoginState")
            UserDefaults.standard.set(signingAPI.currentDoctor.first!.id,forKey: "LoggedUserID")
            UserDefaults.standard.set(signingAPI.currentDoctor.first!.fullName,forKey: "LoggedUserName")
            UserDefaults.standard.set(signingAPI.currentDoctor.first!.emailAddress,forKey: "LoggedUserEmail")
            
            pageState = "HomePage"
            
        }
        else{
            isPageLoading.toggle()
        }
    }
    
    var body: some View {
        VStack{
            Image(systemName: "cross.fill")
                .symbolRenderingMode(.hierarchical)
                .font(.system(size: 80, weight: .bold))
                .foregroundColor(.green)
                .shadow(radius: 5)
            Text("CliniCom")
                .font(.system(size: 28, weight: .medium))
            VStack(spacing:20){
                TextField("Email Address...", text: $emailAddress)
                    .autocorrectionDisabled(true)
                    .autocapitalization(.none)
                    .padding()
                    .background(.black.opacity(0.05))
                    .cornerRadius(10)
                    .font(.system(size: 18, weight: .regular))
                SecureField("Password...", text: $password)
                    .autocorrectionDisabled(true)
                    .autocapitalization(.none)
                    .padding()
                    .background(.black.opacity(0.05))
                    .cornerRadius(10)
                    .font(.system(size: 18, weight: .regular))
                Button(action:{
                    Task{
                        do{
                            await loginDoctor()
                        }
                    }
                }){
                    if(isPageLoading){
                        Text("Loading...")
                            .padding(15)
                            .frame(maxWidth: .infinity)
                            .background(.green)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .font(.system(size: 18, weight: .bold))
                            .disabled(true)
                            .opacity(0.5)
                    }
                    else{
                        Text("Sign In")
                            .padding(15)
                            .frame(maxWidth: .infinity)
                            .background(.green)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .font(.system(size: 18, weight: .bold))
                    }
                }
                HStack{
                    Text("Don't have an account? ")
                    Button(action:{
                        Task{
                            pageState = "SignupPage"
                        }
                    }){
                        Text("Sign Up")
                    }
                }
            }
            .padding(.vertical, 40)
        }
        .padding(.horizontal, 20)
    }
}

struct prevSip: View {
    
    @State var StringVar: String = ""
    @StateObject var signingAPI = usersModel()
    
    var body: some View {
        SigninPage(signingAPI: signingAPI, pageState: $StringVar)
    }
}

#Preview {
    prevSip()
}
