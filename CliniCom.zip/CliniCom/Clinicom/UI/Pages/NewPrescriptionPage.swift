import SwiftUI
import Speech
import AVFoundation

class NewPrescriptionViewModel: ObservableObject {
    @Published var isRecordingAdvices = false
    @Published var advicesText = ""
    
    let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-IN"))
    let audioEngine = AVAudioEngine()
    var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    var recognitionTask: SFSpeechRecognitionTask?
    
    func requestSpeechAuthorization() {
        SFSpeechRecognizer.requestAuthorization { authStatus in
            // Handle speech recognition authorization status
            switch authStatus {
            case .authorized:
                print("Speech recognition authorized")
            case .denied:
                print("User denied speech recognition access")
            case .restricted:
                print("Speech recognition access restricted")
            case .notDetermined:
                print("Speech recognition authorization not determined")
            @unknown default:
                fatalError("Unhandled authorization status")
            }
        }
    }
    
    func toggleRecordingAdvices() {
        isRecordingAdvices.toggle()
        if isRecordingAdvices {
            startRecordingAdvices()
        } else {
            stopRecording()
        }
    }
    func startRecordingAdvices() {
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
            
            recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
            guard let recognitionRequest = recognitionRequest else { return }
            
            recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { result, error in
                guard let result = result else {
                    if let error = error {
                        print("Speech recognition error: \(error.localizedDescription)")
                    }
                    return
                }
                
                if error != nil || result.isFinal {
                    self.stopRecording()
                }
                
                let transcription = result.bestTranscription.formattedString
                DispatchQueue.main.async {
                    self.advicesText = transcription
                }
            }
            
            let recordingFormat = audioEngine.inputNode.outputFormat(forBus: 0)
            audioEngine.inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
                recognitionRequest.append(buffer)
            }
            
            audioEngine.prepare()
            try audioEngine.start()
        } catch {
            print("Audio session error: \(error.localizedDescription)")
        }
    }
    func stopRecording() {
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
    }
}

struct Medicine: Identifiable {
    var id = UUID()
    var name: String = ""
    var dosage: String = ""
    var unitIndex: Int = 0
    var frequency: String = ""
}

struct NewPrescriptionPage: View {
    
    @ObservedObject var signingAPI: usersModel
    @ObservedObject var patientAPI: patientsModel
    @Binding var pageState: String
    @Binding var patientId: Int
    
    @StateObject var viewModel = NewPrescriptionViewModel()
    @State private var medicines: [Medicine] = [Medicine()] // Add default medicine
    @State private var adviceText = ""
    @State private var followUpOption = "Not Required"
    @State private var isFollowUpDateVisible = false
    @State private var followUpDate = Date()

    let units = ["mg", "ml", "drops", "tablets"]
    let followUpOptions = ["Required", "Not Required"]
    
    @State private var isLogged: Bool = UserDefaults.standard.bool(forKey: "LoginState")
    @State private var loggedUserID: String = UserDefaults.standard.string(forKey: "LoggedUserID") ?? ""
    @State private var loggedUserName: String = UserDefaults.standard.string(forKey: "LoggedUserName") ?? ""
    @State private var loggedUserEmail: String = UserDefaults.standard.string(forKey: "LoggedUserEmail") ?? ""
    //@Binding var prescriptionFiles: [String]

    var body: some View {
        VStack {
            ScrollView {
                HStack {
                    Text("Medicines")
                        .font(.headline)
                        .foregroundColor(.black)
                        .padding(.leading)
                    
                    Spacer()
                    
                    Button(action: {
                        addMedicine()
                    }) {
                        Image(systemName: "plus")
                            .font(.headline)
                            .foregroundColor(.blue)
                            .padding(.trailing)
                    }
                }
                .padding(.horizontal)
                
                ForEach(medicines.indices, id: \.self) { index in // Use indices
                    MedicineEntryView(medicine: $medicines[index])
                        .padding(.horizontal)
                        .padding(.vertical, 4)
                        .background(RoundedRectangle(cornerRadius: 10)
                                        .fill(Color.white)
                                        .opacity(0.4)
                                        .shadow(radius: 3))
                        .padding(.horizontal)
                        .contextMenu {
                            Button(action: {
                                removeMedicine(at: index)
                            }) {
                                Text("Delete")
                                Image(systemName: "trash")
                            }
                        }
                }
                
                Spacer(minLength: 25)
                VStack{
                    HStack {
                        Text("Advices")
                            .font(.headline)
                            .foregroundColor(.black)
                            .padding(.leading)
                        
                        Spacer()
                        
                        Button(action: {
                            viewModel.toggleRecordingAdvices()
                        }) {
                            Image(systemName: viewModel.isRecordingAdvices ? "mic.fill" : "mic")
                                .foregroundColor(viewModel.isRecordingAdvices ? .red : .blue)
                        }
                        
                    }
                    .padding(.horizontal)
                    
                    TextEditor(text: $viewModel.advicesText)
                        .frame(maxWidth: .infinity)
                        .frame(height: 200)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 10)
                            .fill(Color.white)
                            .opacity(0.7)
                            .shadow(radius: 3)
                            .padding(.horizontal))

                    Spacer(minLength: 20)
                    
                    HStack {
                        Text("Follow-Up")
                            .font(.headline)
                            .foregroundColor(.black)
                            .padding(.leading)
                        
                        Spacer()
                        
                        Picker(selection: $followUpOption, label: Text("")) {
                            ForEach(followUpOptions, id: \.self) { option in
                                Text(option)
                            }
                        }
                        .pickerStyle(MenuPickerStyle())
                        .frame(width: 150)
                        
                        if followUpOption == "Required" {
                            Button(action: {
                                isFollowUpDateVisible.toggle()
                            }) {
                                Image(systemName: "calendar")
                                    .font(.headline)
                                    .foregroundColor(.black)
                                    .padding(.trailing)
                            }
                        }
                    }
                    .padding(.horizontal)
                    
                    if isFollowUpDateVisible {
                        DatePicker(selection: $followUpDate, in: Date()..., displayedComponents: .date) {
                            Text("")
                        }
                        .padding()
                    }
                    
                    Spacer()
                }
            }
            Button(action: {
                generateAndSharePrescription()
                Task{
                    await savePres()
                }
            }) {
                Text("Generate Prescription")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(RoundedRectangle(cornerRadius: 10).fill(Color.teal))
                    .padding()
            }
            .padding()


        }
        .background(
            LinearGradient(gradient: Gradient(colors: [.green.opacity(0.5), .white]), startPoint: .bottom, endPoint: .top)
        )
    }

    func addMedicine() {
            medicines.append(Medicine())
        }
        
        func removeMedicine(at index: Int) {
            medicines.remove(at: index)
        }
    func savePres() async{
        
        var medData = ""
        for medicine in medicines {
            medData += String(medicine.name)+","+String(medicine.dosage)+String(medicine.unitIndex)+","+String(medicine.frequency)+"|"
        }
        try! await patientAPI.addPres(patientId: patientId, doctorId: Int(loggedUserID)!, medicines: medData, advice: String(viewModel.advicesText), nextVisit: followUpDate.formatted())
        
    }
    func generateAndSharePrescription() {
        // Create PDF content
        var pdfContent = "Prescription Details:\n\n"
        
        // Medicine details
        pdfContent += "Medicines:\n"
        for medicine in medicines {
            pdfContent += "- Name: \(medicine.name)\n"
            pdfContent += "  Dosage: \(medicine.dosage) \(units[medicine.unitIndex])\n"
            pdfContent += "  Frequency: \(medicine.frequency)\n\n"
        }
        
        // Advice details
        pdfContent += "Advices:\n\(viewModel.advicesText)\n\n"
        
        // Follow-up details
        pdfContent += "Follow-Up: \(followUpOption)\n"
        if followUpOption == "Required" {
            pdfContent += "Date: \(followUpDate)\n"
        }
        
        // Create PDF data
        let pdfData = NSMutableData()
        UIGraphicsBeginPDFContextToData(pdfData, CGRect.zero, nil)
        UIGraphicsBeginPDFPage()
        let textRect = CGRect(x: 20, y: 20, width: 300, height: 600) // Adjust dimensions as needed
        pdfContent.draw(in: textRect, withAttributes: nil)
        UIGraphicsEndPDFContext()
        
        // Save PDF to file
        guard let documentsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            print("Documents directory not found")
            return
        }
        
        let fileName = "Prescription-\(Date().timeIntervalSince1970).pdf"
        let fileUrl = documentsUrl.appendingPathComponent(fileName)
        
        do {
            try pdfData.write(to: fileUrl)
            sharePDF(fileUrl)
        } catch {
            print("Error writing PDF to file: \(error)")
        }
    }

        
        private func sharePDF(_ fileUrl: URL) {
            if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
                let activityViewController = UIActivityViewController(activityItems: [fileUrl], applicationActivities: nil)
                windowScene.windows.first?.rootViewController?.present(activityViewController, animated: true, completion: nil)
            }
        }
    }

struct MedicineEntryView: View {
    @Binding var medicine: Medicine
    
    var units = ["mg", "ml", "drops", "tablets"]
    
    var body: some View {
        VStack(alignment: .leading) {
            TextField("Medicine Name", text: $medicine.name)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.vertical, 8)
                .opacity(0.9)
            
            HStack {
                TextField("Dosage", text: $medicine.dosage)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .frame(width: 80)
                    .opacity(0.9)
                
                Picker(selection: $medicine.unitIndex, label: Text("")) {
                    ForEach(0..<units.count) {
                        Text(self.units[$0])
                    }
                }
                .pickerStyle(MenuPickerStyle())
                .frame(width: 100)
                .opacity(0.9)
                
                TextField("Frequency", text: $medicine.frequency)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .frame(width: 100)
                    .opacity(0.9)
            }
        }
        .padding(.vertical)
    }
}

struct prevNprp: View {
    
    @State var StringVar: String = ""
    @State var IntVar: Int = 0
    @StateObject var signingAPI = usersModel()
    @StateObject var patientAPI = patientsModel()
    
    var body: some View {
        NewPrescriptionPage(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $StringVar, patientId: $IntVar)
    }
}

#Preview {
    prevNprp()
}
