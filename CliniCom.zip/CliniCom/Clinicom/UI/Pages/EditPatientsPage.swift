//
//  EditPatientsPage.swift
//  Clinicom
//
//  Created by user1 on 26/03/24.
//

import SwiftUI

struct EditPatientsPage: View {
    
    @State private var isEditing = false
    @State private var name = ""
    @State private var contactNumber = ""
    @State private var age = ""
    @State private var weight = ""
    @State private var gender = ""
    @State private var bloodGroup = ""
    @State private var diagnosis = ""
    @State private var isPatientActive = true

    @ObservedObject var patientAPI: patientsModel
    
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading) {
                    VStack(alignment: .leading) {
                        Text("Name:")
                            .font(.headline)
                            .padding(.horizontal)
                        TextField("\(patientAPI.currentPatient[0].fullName)", text: $name)
                            .autocorrectionDisabled(true)
                            .autocapitalization(.none)
                            .padding()
                            .background(.black.opacity(0.05))
                            .cornerRadius(10)
                            .font(.system(size: 18, weight: .regular))
                            .disabled(!isEditing)
                    }
                    
                    VStack(alignment: .leading) {
                        Text("Mobile Number:")
                            .font(.headline)
                            .padding(.horizontal)
                        TextField("\(patientAPI.currentPatient[0].mobileNumber)", text: $contactNumber)
                            .autocorrectionDisabled(true)
                            .autocapitalization(.none)
                            .padding()
                            .background(.black.opacity(0.05))
                            .cornerRadius(10)
                            .font(.system(size: 18, weight: .regular))
                            .disabled(!isEditing) // Add spacing after text field
                    }
                    
                    VStack(alignment: .leading) {
                        Text("Age:")
                            .font(.headline)
                            .padding(.horizontal)
                        TextField("\(patientAPI.currentPatient[0].age)", text: $age)
                            .autocorrectionDisabled(true)
                            .autocapitalization(.none)
                            .padding()
                            .background(.black.opacity(0.05))
                            .cornerRadius(10)
                            .font(.system(size: 18, weight: .regular))
                            .disabled(!isEditing) // Add spacing after text field
                    }
                    
                    VStack(alignment: .leading) {
                        Text("Weight:")
                            .font(.headline)
                            .padding(.horizontal)
                        TextField("\(patientAPI.currentPatient[0].weight)", text: $weight)
                            .autocorrectionDisabled(true)
                            .autocapitalization(.none)
                            .padding()
                            .background(.black.opacity(0.05))
                            .cornerRadius(10)
                            .font(.system(size: 18, weight: .regular))
                            .disabled(!isEditing) // Add spacing after text field
                    }
                    
                    VStack(alignment: .leading) {
                        Text("Gender")
                            .font(.headline)
                            .padding(.horizontal)
                        TextField("\(patientAPI.currentPatient[0].gender)", text: $gender)
                            .autocorrectionDisabled(true)
                            .autocapitalization(.none)
                            .padding()
                            .background(.black.opacity(0.05))
                            .cornerRadius(10)
                            .font(.system(size: 18, weight: .regular))
                            .disabled(!isEditing) // Add spacing after text field
                    }
                    
                    VStack(alignment: .leading) {
                        Text("Blood Group")
                            .font(.headline)
                            .padding(.horizontal)
                        TextField("\(patientAPI.currentPatient[0].bloodGroup)", text: $bloodGroup)
                            .autocorrectionDisabled(true)
                            .autocapitalization(.none)
                            .padding()
                            .background(.black.opacity(0.05))
                            .cornerRadius(10)
                            .font(.system(size: 18, weight: .regular))
                            .disabled(!isEditing) // Add spacing after text field
                    }
                    
                    Text("Patient Status")
                        .font(.headline)
                        .padding(.horizontal)
                        .padding(.top)
                    
                    Toggle(isOn: $isPatientActive) {
                        Text(isPatientActive ? "Active" : "Closed")
                    }
                    .padding()
                    
                }
            }
            .navigationBarTitle("Edit Patient", displayMode: .inline)
            .navigationBarItems(trailing: Button(action: {
                if isEditing {
                    // Save button tapped, perform save operation here
                }
                isEditing.toggle()
            }) {
                Text(isEditing ? "Save" : "Edit")
            })
            .padding()
        }
    }
}
