import SwiftUI

struct HomePage: View {
    
    @ObservedObject var signingAPI: usersModel
    @ObservedObject var patientAPI: patientsModel
    @Binding var pageState: String
    
    @State private var isLogged: Bool = UserDefaults.standard.bool(forKey: "LoginState")
    @State private var loggedUserID: String = UserDefaults.standard.string(forKey: "LoggedUserID") ?? ""
    @State private var loggedUserName: String = UserDefaults.standard.string(forKey: "LoggedUserName") ?? ""
    @State private var loggedUserEmail: String = UserDefaults.standard.string(forKey: "LoggedUserEmail") ?? ""
    
    var body: some View {
        VStack(spacing:30){
            HStack{
                VStack(alignment: .leading){
                    Text("Welcome back,")
                        .font(.system(size: 18, weight: .medium))
                    Text("Dr. \(loggedUserName)")
                        .font(.system(size: 26, weight: .semibold))
                }
                Spacer()
            }
            VStack(spacing: 10){
                HStack{
                    Text("Active Patients:")
                    Spacer()
                    Text("\(patientAPI.activePatients.count)")
                }
                Divider()
                    .opacity(0.5)
                HStack{
                    Text("Inactive Patients:")
                    Spacer()
                    Text("\(patientAPI.inactivePatients.count)")
                }
                Divider()
                    .opacity(0.5)
                HStack{
                    Text("Total Patients:")
                    Spacer()
                    Text("\(patientAPI.activePatients.count + patientAPI.inactivePatients.count)")
                }
            }
            .padding()
            .background(.white.opacity(0.5))
            .cornerRadius(10)
            Spacer()
        }
        .padding(.vertical,10)
        .padding(.horizontal, 20)
        .task{
            do{
                try! await signingAPI.getCurrentDoctor(id: Int(loggedUserID)!)
                try! await patientAPI.getCurrentPatients(id: Int(loggedUserID)!)
            }
        }
    }
}

struct prevHp: View {
    
    @State var StringVar: String = ""
    @StateObject var signingAPI = usersModel()
    @StateObject var patientAPI = patientsModel()
    
    var body: some View {
        HomePage(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $StringVar)
    }
}

//#Preview {
//    prevHp()
//}
