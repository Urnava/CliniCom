import SwiftUI

struct LaunchPage: View {
    
    @ObservedObject var signingAPI: usersModel
    @ObservedObject var patientAPI: patientsModel
    @Binding var pageState: String
    
    @State private var isLogged: Bool = UserDefaults.standard.bool(forKey: "LoginState")
    @State private var loggedUserID: String = UserDefaults.standard.string(forKey: "LoggedUserID") ?? ""
    @State private var loggedUserName: String = UserDefaults.standard.string(forKey: "LoggedUserName") ?? ""
    @State private var loggedUserEmail: String = UserDefaults.standard.string(forKey: "LoggedUserEmail") ?? ""
    
    func homeSwitch() async{
        if(isLogged){
            try! await signingAPI.getCurrentDoctor(id: Int(loggedUserID)!)
            try! await patientAPI.getCurrentPatients(id: Int(loggedUserID)!)
//            try? await userModel.getUser(emailAddress: loggedUserEmail)
//            try? await userModel.getStats()
//            try? await userModel.getGlobalRank(userID: Int(loggedUserID)!)
//            try? await pickupModel.getActivePickups(userId: Int(loggedUserID)!)
//            try? await pickupModel.getPickups(userId: Int(loggedUserID)!)
            withAnimation{
                pageState = "HomePage"
            }
        }
        else{
            try? await Task.sleep(nanoseconds: 1_000_000_000)
                withAnimation{
                    pageState = "SigninPage"
                }
        }
    }
    
    var body: some View {
        VStack(spacing:10){
            Image(systemName: "cross.fill")
                .symbolRenderingMode(.hierarchical)
                .font(.system(size: 80, weight: .bold))
                .foregroundColor(.green)
                .shadow(radius: 5)
            Text("CliniCom")
                .font(.system(size: 28, weight: .medium))
            HStack{
                Text("Simplify")
                    .font(.system(size: 20))
                Image(systemName: "circle.fill")
                    .symbolRenderingMode(.hierarchical)
                    .font(.system(size: 12))
                    .foregroundColor(.green)
                Text("Connect")
                    .font(.system(size: 20))
                Image(systemName: "circle.fill")
                    .symbolRenderingMode(.hierarchical)
                    .font(.system(size: 12))
                    .foregroundColor(.green)
                Text("Heal")
                    .font(.system(size: 20))
            }
        }
        .task {
            await homeSwitch()
        }
    }
}

struct prevLP: View {
    
    @State var StringVar: String = ""
    @StateObject var signingAPI = usersModel()
    @StateObject var patientAPI = patientsModel()
    
    var body: some View {
        LaunchPage(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $StringVar)
    }
}

#Preview {
    prevLP()
}
