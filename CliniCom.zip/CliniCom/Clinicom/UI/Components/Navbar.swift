import SwiftUI

struct Navbar: View {
    var body: some View {
        VStack{
            HStack{
                Image(systemName: "cross.fill")
                    .symbolRenderingMode(.hierarchical)
                    .foregroundColor(.green)
                    .font(.system(size: 20, weight: .light))
                Text("CliniCom")
                    .font(.system(size: 20, weight: .medium))
            }
        }
        .padding()
        .frame(maxWidth: .infinity)
        .overlay(
            Rectangle()
                .frame(height: 1, alignment: .bottom)
                .foregroundColor(.black.opacity(0.25)),
            alignment: .bottom
        )
    }
}

#Preview {
    Navbar()
}
