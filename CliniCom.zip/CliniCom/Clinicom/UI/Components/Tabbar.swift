//
//  Tabbar.swift
//  Clinicom
//
//  Created by user1 on 26/03/24.
//

import SwiftUI

struct Tabbar: View {
    
    @Binding var pageState: String
    
    var body: some View {
        VStack{
            HStack(spacing:60){
                Button(action:{
                    pageState = "HomePage"
                }){
                    if(pageState == "HomePage"){
                        VStack(spacing:10){
                            Image(systemName: "cross.fill")
                                .symbolRenderingMode(.hierarchical)
                            Text("Home")
                        }
                        .foregroundColor(.green)
                    }
                    else{
                        VStack(spacing:10){
                            Image(systemName: "cross.fill")
                                .symbolRenderingMode(.hierarchical)
                            Text("Home")
                        }
                        .foregroundColor(.black.opacity(0.5))
                    }
                }
                Button(action:{
                    pageState = "PatientsPage"
                }){
                    if(pageState == "PatientsPage" || pageState == "PatientPage" || pageState == ""){
                        VStack(spacing:10){
                            Image(systemName: "person.3.fill")
                                .symbolRenderingMode(.hierarchical)
                            Text("Patients")
                        }
                        .foregroundColor(.green)
                    }
                    else{
                        VStack(spacing:10){
                            Image(systemName: "person.3.fill")
                                .symbolRenderingMode(.hierarchical)
                            Text("Patients")
                        }
                        .foregroundColor(.black.opacity(0.5))
                    }
                }
                Button(action:{
                    pageState = "ProfilePage"
                }){
                    if(pageState == "ProfilePage"){
                        VStack(spacing:10){
                            Image(systemName: "person.bust.fill")
                                .symbolRenderingMode(.hierarchical)
                            Text("Profile")
                        }
                        .foregroundColor(.green)
                    }
                    else{
                        VStack(spacing:10){
                            Image(systemName: "person.bust.fill")
                                .symbolRenderingMode(.hierarchical)
                            Text("Profile")
                        }
                        .foregroundColor(.black.opacity(0.5))
                    }
                }
            }
        }
        .padding()
        .frame(maxWidth: .infinity)
//        .overlay(
//            Rectangle()
//                .frame(height: 1, alignment: .bottom)
//                .foregroundColor(.black.opacity(0.25)),
//            alignment: .top
//        )
    }
}

struct prevTb: View {
    
    @State var StringVar: String = ""
    @StateObject var signingAPI = usersModel()
    
    var body: some View {
        Tabbar(pageState: $StringVar)
    }
}

#Preview {
    prevTb()
}
