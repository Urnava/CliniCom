//
//  ContentView.swift
//  Clinicom
//
//  Created by user1 on 26/03/24.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var signingAPI = usersModel()
    @StateObject var patientAPI = patientsModel()
    @State var pageState: String = "LaunchPage"
    @State var currentPatientID: Int = 0
    
    var body: some View {
        if(pageState == "LaunchPage"){
            LaunchPage(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $pageState)
        }
        else if(pageState == "SigninPage"){
            SigninPage(signingAPI: signingAPI, pageState: $pageState)
        }
        else if(pageState == "SignupPage"){
            SignupPage(signingAPI: signingAPI, pageState: $pageState)
        }
        else{
            ZStack{
                LinearGradient(gradient: Gradient(colors: [.green.opacity(0.5), .white]), startPoint: .bottom, endPoint: .top)
                    .edgesIgnoringSafeArea(.all)
                VStack{
                    Navbar()
                    Spacer()
                    if(pageState == "HomePage"){
                        HomePage(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $pageState)
                    }
                    else if(pageState == "PatientsPage"){
                        PatientsPage(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $pageState, currentPatientId: $currentPatientID)
                    }
                    else if(pageState == "PatientPage"){
                        PatientPage(signingAPI: signingAPI, patientAPI: patientAPI, pageState: $pageState, patientId: $currentPatientID)
                    }
                    else if(pageState == "ProfilePage"){
                        ProfilePage(signingAPI: signingAPI, pageState: $pageState)
                    }
                    else if(pageState == "EditPage"){
                        EditPatientsPage(patientAPI: patientAPI)
                    }
                    Spacer()
                    Tabbar(pageState: $pageState)
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
