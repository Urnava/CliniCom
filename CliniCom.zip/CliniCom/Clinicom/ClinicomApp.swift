//
//  ClinicomApp.swift
//  Clinicom
//
//  Created by user1 on 26/03/24.
//

import SwiftUI

@main
struct ClinicomApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
