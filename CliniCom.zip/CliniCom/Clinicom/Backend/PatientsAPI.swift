import Foundation
import Supabase

final class patientsModel: ObservableObject{
    
    @Published var activePatients = [getPatients]()
    @Published var inactivePatients = [getPatients]()
    @Published var currentPatient = [getPatients]()
    @Published var currentPatientPres = [getPrescriptions]()
    @Published var currentPatientHist = [getHistory]()
    @Published var responseStatus = 000
    @Published var responseMessage = "No API called"
    
    let supabase = SupabaseClient(supabaseURL: Secrets.projectURL!, supabaseKey: Secrets.apiKey)
    
    func getCurrentPatients(id: Int) async throws{
        
        self.responseStatus = 100
        self.responseMessage = "API called"
        
        print("Called")
        print(id)
        
        let activePati: [getPatients] = try await supabase.database
            .from(Tabel.Patients)
            .select()
            .eq("doctorId", value: id)
            .eq("status", value: "active")
            .execute()
            .value
        
        let inactivePati: [getPatients] = try await supabase.database
            .from(Tabel.Patients)
            .select()
            .eq("doctorId", value: id)
            .eq("status", value: "inactive")
            .execute()
            .value
        print(activePati)
        print(inactivePati)
        self.activePatients = activePati
        self.inactivePatients = inactivePati
        self.responseStatus = 200
        self.responseMessage = "API responded"
    }
    
    func addPatient(fullName: String, mobileNumber: String, age: Int, weight: Int, gender: String, bloodGroup: String, doctorID: Int) async throws{
        
        self.responseStatus = 100
        self.responseMessage = "API called"
        
        let newPatient = addPatients(doctorId: doctorID, fullName: fullName, mobileNumber: mobileNumber, age: age, weight: weight, gender: gender, bloodGroup: bloodGroup, status: "active")
        
        try await supabase.database
            .from(Tabel.Patients)
            .insert(newPatient)
            .execute()
        
        self.responseStatus = 200
        self.responseMessage = "Patient added successfully"
        
    }
    
    func getCurrentPatient(id: Int) async throws{
        
        self.responseStatus = 100
        self.responseMessage = "API called"
        
        let currentPatient: [getPatients] = try await supabase.database
            .from(Tabel.Patients)
            .select()
            .eq("id", value: id)
            .execute()
            .value
        
        self.currentPatient = currentPatient
        self.responseStatus = 200
        self.responseMessage = "API responded"
    }
    
    func addPres(patientId: Int, doctorId: Int, medicines: String, advice: String, nextVisit: String) async throws{
        
        self.responseStatus = 100
        self.responseMessage = "API called"
        
        let newPres = addPrescriptions(doctorId: doctorId, patientId: patientId, medicines: medicines, advice: advice, nextVisit: nextVisit)
        
        try await supabase.database
            .from(Tabel.Prescriptions)
            .insert(newPres)
            .execute()
        
        self.responseStatus = 200
        self.responseMessage = "API responded"
    }
    
    func getPres(id: Int) async throws{
        self.responseStatus = 100
        self.responseMessage = "API called"
        
        let currentPatient: [getPrescriptions] = try await supabase.database
            .from(Tabel.Prescriptions)
            .select()
            .eq("patientId", value: id)
            .execute()
            .value
        
        self.currentPatientPres = currentPatient
        self.responseStatus = 200
        self.responseMessage = "API responded"
    }
    
    func addHist(patientId: Int, doctorID:Int, fullName: String, mobileNumber: String, age: Int, weight: Int, gender: String, bloodGroup: String, analysis: String) async throws{
        
        self.responseStatus = 100
        self.responseMessage = "API called"
        
        let newHist = addHistory(doctorId: doctorID, patientId: patientId, fullName: fullName, mobileNumber: mobileNumber, age: age, weight: weight, gender: gender, bloodGroup: bloodGroup, analysis: analysis)
        
        try await supabase.database
            .from(Tabel.History)
            .insert(newHist)
            .execute()
        
        self.responseStatus = 200
        self.responseMessage = "API responded"
        
    }
    
    func getHist(id: Int) async throws{
        self.responseStatus = 100
        self.responseMessage = "API called"
        
        let currentPatient: [getHistory] = try await supabase.database
            .from(Tabel.History)
            .select()
            .eq("patientId", value: id)
            .execute()
            .value
        print(currentPatient)
        self.currentPatientHist = currentPatient
        self.responseStatus = 200
        self.responseMessage = "API responded"
    }
    
}
