import Foundation

struct getDoctors: Decodable, Identifiable, Hashable{
    
    var id: Int?
    var fullName: String
    var emailAddress: String
    var mobileNumber: String
    var medicalToken: String
    var medicalQualification: String
    var clinicAddress: String
    var password: String
    var createdAt: Date?
    
    enum CodingKeys: String, CodingKey {
        case id, fullName, emailAddress, mobileNumber, medicalToken, medicalQualification, clinicAddress, password, createdAt
    }
    
}

struct addDoctors: Encodable, Identifiable, Hashable{
    
    var id: Int?
    var fullName: String
    var emailAddress: String
    var mobileNumber: String
    var medicalToken: String
    var medicalQualification: String
    var clinicAddress: String
    var password: String
    var createdAt: Date?
    
    enum CodingKeys: String, CodingKey {
        case id, fullName, emailAddress, mobileNumber, medicalToken, medicalQualification, clinicAddress, password, createdAt
    }
    
}

struct getPatients: Decodable, Identifiable, Hashable{
    
    var id: Int?
    var doctorId: Int
    var fullName: String
    var mobileNumber: String
    var age: Int
    var weight: Int
    var gender: String
    var bloodGroup: String
    var status: String
    var createdAt: Date?
    
    enum CodingKeys: String, CodingKey {
        case id, doctorId, fullName, mobileNumber, age, weight, gender, bloodGroup,status, createdAt
    }
    
}

struct addPatients: Encodable, Identifiable, Hashable{
    
    var id: Int?
    var doctorId: Int
    var fullName: String
    var mobileNumber: String
    var age: Int
    var weight: Int
    var gender: String
    var bloodGroup: String
    var status: String
    var createdAt: Date?
    
    enum CodingKeys: String, CodingKey {
        case id, doctorId, fullName, mobileNumber, age, weight, gender, bloodGroup,status, createdAt
    }
    
}

struct getHistory: Decodable, Identifiable, Hashable{
    
    var id: Int?
    var doctorId: Int
    var patientId: Int
    var fullName: String
    var mobileNumber: String
    var age: Int
    var weight: Int
    var gender: String
    var bloodGroup: String
    var analysis: String
    var createdAt: Date?
    
    enum CodingKeys: String, CodingKey {
        case id, doctorId, patientId, fullName, mobileNumber, age, weight, gender, bloodGroup,analysis, createdAt
    }
    
}

struct addHistory: Encodable, Identifiable, Hashable{
    
    var id: Int?
    var doctorId: Int
    var patientId: Int
    var fullName: String
    var mobileNumber: String
    var age: Int
    var weight: Int
    var gender: String
    var bloodGroup: String
    var analysis: String
    var createdAt: Date?
    
    enum CodingKeys: String, CodingKey {
        case id, doctorId, patientId, fullName, mobileNumber, age, weight, gender, bloodGroup,analysis, createdAt
    }
    
}

struct getPrescriptions: Decodable, Identifiable, Hashable{
    
    var id: Int?
    var doctorId: Int
    var patientId: Int
    var medicines: String
    var advice: String
    var nextVisit: String?
    var createdAt: Date?
    
    enum CodingKeys: String, CodingKey {
        case id, doctorId, patientId, medicines,advice,nextVisit, createdAt
    }
    
}

struct addPrescriptions: Encodable, Identifiable, Hashable{
    
    var id: Int?
    var doctorId: Int
    var patientId: Int
    var medicines: String
    var advice: String
    var nextVisit: String?
    var createdAt: Date?
    
    enum CodingKeys: String, CodingKey {
        case id, doctorId, patientId, medicines,advice,nextVisit, createdAt
    }
    
}
