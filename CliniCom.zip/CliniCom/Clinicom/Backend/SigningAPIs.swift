import Foundation
import Supabase

enum Tabel{
    
    static let Doctors = "Doctors"
    static let Patients = "Patients"
    static let Prescriptions = "Prescriptions"
    static let History = "History"
    
}

enum Defaults{
    
    static let profileImage = "https://firebasestorage.googleapis.com/v0/b/greenwealth-68871.appspot.com/o/Profile.png?alt=media&token=27712235-9bd0-414a-9b70-53125764e872"
    
    static let imageURL = "https://firebasestorage.googleapis.com/v0/b/greenwealth-68871.appspot.com/o/demo.png?alt=media&token=ab43aad1-9825-4e44-b78c-422a231be7cf"
    
}

final class usersModel: ObservableObject{
    
    @Published var currentDoctor = [getDoctors]()
    @Published var responseStatus = 000
    @Published var responseMessage = "No API called"
    
    let supabase = SupabaseClient(supabaseURL: Secrets.projectURL!, supabaseKey: Secrets.apiKey)
    
    func addDoctor(fullName: String,emailAddress: String,mobileNumber: String,medicalToken: String,medicalQualification: String,clinicAddress: String,password: String) async throws{
        
        self.responseStatus = 100
        self.responseMessage = "API called"
        
        let existingDoctor: [getDoctors] = try await supabase.database
            .from(Tabel.Doctors)
            .select()
            .eq("emailAddress", value: emailAddress)
            .execute()
            .value
        
        if(existingDoctor.isEmpty){
            
            let newDoctor = addDoctors(fullName: fullName, emailAddress: emailAddress, mobileNumber: mobileNumber, medicalToken: medicalToken, medicalQualification: medicalQualification, clinicAddress: clinicAddress, password: password)
            
            try await supabase.database
                .from(Tabel.Doctors)
                .insert(newDoctor)
                .execute()
            
            let currentDoctor: [getDoctors] = try await supabase.database
                .from(Tabel.Doctors)
                .select()
                .eq("emailAddress", value: emailAddress)
                .execute()
                .value
            
            self.currentDoctor = currentDoctor
            self.responseStatus = 200
            self.responseMessage = "Doctor added successfully."
            
        }
        
        else{
            self.responseStatus = 400
            self.responseMessage = "Failed to add doctor."
        }
        
    }
    
    func loginDoctor(emailAddress: String,password: String) async throws{
        
        self.responseStatus = 100
        self.responseMessage = "API called"
        
        let currentDoctor: [getDoctors] = try await supabase.database
            .from(Tabel.Doctors)
            .select()
            .eq("emailAddress", value: emailAddress)
            .execute()
            .value
        if(!currentDoctor.isEmpty){
            if(currentDoctor[0].password == password){
                self.currentDoctor = currentDoctor
                self.responseStatus = 200
                self.responseMessage = "Doctor loggedin successfully."
            }
            else{
                self.responseStatus = 400
                self.responseMessage = "Incorrect password."
            }
        }
        else{
            self.responseStatus = 401
            self.responseMessage = "Invalid email."
        }
    }
    
    func getCurrentDoctor(id: Int) async throws{
        let currentDoctor: [getDoctors] = try await supabase.database
            .from(Tabel.Doctors)
            .select()
            .eq("id", value: id)
            .execute()
            .value
        if(!currentDoctor.isEmpty){
            self.currentDoctor = currentDoctor
            self.responseStatus = 200
            self.responseMessage = "Doctor loggedin successfully."
        }
        else{
            self.responseStatus = 400
            self.responseMessage = "Incorrect id."
        }
    }
}
