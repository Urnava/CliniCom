import Foundation

enum Secrets{
    
    static let projectURL = URL(string: "https://jmwcuaoploqdlaizsxtf.supabase.co")
    static let apiKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imptd2N1YW9wbG9xZGxhaXpzeHRmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTEzOTEyNjQsImV4cCI6MjAyNjk2NzI2NH0.utrO1A5xaA3jAEfC2XJFIIG8jJb95gSxMKHHz3umehE"
    
}
